package com.example.demo.service;

import com.example.demo.Repository.TareaRepository;
import com.example.demo.entity.Tarea;
import com.example.demo.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;
//import com.example.demo.exception.ResourceNotFoundException;

import java.util.List;

@Service
public class TareaServiceImpl implements TareaService {

    //ENTIDAD
    private final TareaRepository tareaRepository;

    public TareaServiceImpl(TareaRepository tareaRepository) {
        this.tareaRepository = tareaRepository;
    }


    @Override
    public Tarea save(Tarea tarea) {
        return tareaRepository.save(tarea);
    }

    @Override
    public List<Tarea> findAll() {
        return tareaRepository.findAll();
    }

    @Override
    public Tarea findById(Integer id) {
        //Manejo de errores
        Tarea customer = tareaRepository.findById(id).orElseThrow(
                () -> {
                    throw new ResourceNotFoundException("Tarea con id "+id+" no encontrado.");
                }
        );
        //return customerRepository.findById(id).get();
        return customer;
    }

    @Override
    public void deleteById(Integer id) {
        // Verificar si la tarea existe antes de intentar eliminarla
        Tarea tarea = tareaRepository.findById(id).orElseThrow(
                () -> new ResourceNotFoundException("Tarea con id " + id + " no encontrado.")
        );

        // Si la tarea existe, eliminarla
        tareaRepository.deleteById(id);
    }

    @Override
    public Tarea update(Tarea tarea) {
        //Metodo save si se envia un id (actualiza), sino crea un nuevo registro
        return tareaRepository.save(tarea);
    }
}
