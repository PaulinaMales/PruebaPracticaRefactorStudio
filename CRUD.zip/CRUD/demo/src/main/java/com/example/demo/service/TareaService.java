package com.example.demo.service;
import com.example.demo.entity.Tarea;

import java.util.List;

public interface TareaService {
    //METODOS CRUD
    Tarea save(Tarea tarea);
    List<Tarea> findAll();
    Tarea findById (Integer id);
    void deleteById(Integer id);
    Tarea update(Tarea tarea);
}
