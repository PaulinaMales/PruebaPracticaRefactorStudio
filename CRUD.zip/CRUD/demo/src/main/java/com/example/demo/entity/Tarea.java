package com.example.demo.entity;

import jakarta.persistence.*;

//Mapearse como tabla de datos
@Entity
//Personalizar el nombre de la tabla
@Table(name="tareas")
public class Tarea {
    //Clave primaria
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    //Definir atributos (Columnas)
    private Integer id;//Autoincremental
    @Column(nullable = false)
    private String titulo;
    @Column(nullable = true)
    private String descripcion;
    private  Boolean completado=false;

    //Contructores
    public Tarea() {
    }

    //Atributos de la clase
    public Tarea(Integer id, String titulo, String descripcion, Boolean completado) {
        this.id = id;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.completado = completado;
    }


    //Crear getter y setter para acceder a los atributos

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Boolean getCompletado() {
        return completado;
    }

    public void setCompletado(Boolean completado) {
        this.completado = completado;
    }
}
