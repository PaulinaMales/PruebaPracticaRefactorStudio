package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

//@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException{

    //Personalizar el response de errores
    private String message;
    //CONTRUCTOR
    public  ResourceNotFoundException(String message){
        super(message);
        this.message=message; //Mensaje que se mostrará

    }
}
