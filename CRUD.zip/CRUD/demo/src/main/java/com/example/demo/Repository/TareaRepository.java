package com.example.demo.Repository;

import com.example.demo.entity.Tarea;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
//Parametros (Nombre de la clase, tipo de dato de la clave primaria de la clase )
public interface TareaRepository extends JpaRepository <Tarea, Integer>{

}
