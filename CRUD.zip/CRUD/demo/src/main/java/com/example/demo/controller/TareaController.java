package com.example.demo.controller;

import com.example.demo.entity.Tarea;
import com.example.demo.service.TareaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tareas")
//ESPEIFICAR QUE CLIENTE ACCEDERA
@CrossOrigin(origins = "http://localhost:4200")

public class TareaController {
    //Objeto
    private final TareaService tareaService;

    //Inyectar
    public TareaController(TareaService tareaService){ this.tareaService = tareaService; }

    //Crear endpoints
    //URL: http://localhost:8080/api/tareas
    @PostMapping//Maneja peticiones tipo POST
    //@RequestBody = Transforma el json del cliente a un objeto java
    public Tarea save(@RequestBody Tarea tarea) {
        if (tarea.getId() != null && tarea.getId() == 0) {
            tarea.setId(null);
        }
        return tareaService.save(tarea);
    }

    @GetMapping //Maneja peticiones tipo GET
    public List<Tarea> findAll(){
        return tareaService.findAll();
    }
    @GetMapping("/{id}") //Maneja peticiones tipo GET, con parametro
    //Mapea el nombre de la variable que viene en la url
    public Tarea findById(@PathVariable  Integer id){
        return tareaService.findById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable  Integer id){
        tareaService.deleteById(id);
    }

    @PutMapping
    public Tarea updateTarea(@RequestBody Tarea tarea){
        Tarea tareaDb=tareaService.findById(tarea.getId());
        tareaDb.setTitulo(tarea.getTitulo());
        tareaDb.setDescripcion(tarea.getDescripcion());
        tareaDb.setCompletado(tarea.getCompletado());
        return tareaService.update(tareaDb);
    }
}
