import { Tarea } from './tarea';

describe('Tarea', () => {
  it('should create an instance', () => {
    expect(new Tarea()).toBeTruthy();
  });
});
