import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Tarea } from '../tarea';

@Injectable({
  providedIn: 'root'
})
export class TareaService {
  //Conectamos a nuestro endpoint
  private api:string='http://localhost:8080/api/tareas';
  constructor(private http:HttpClient) { }

  //Metodo
  getTareaList():Observable<Tarea []>{
    return this.http.get<Tarea[]>(this.api);
  }

  createTarea(tarea:Tarea):Observable<Tarea>{
    return this.http.post<Tarea>(this.api, tarea);
  }

  updateTareaById(tarea: Tarea): Observable<Tarea> {
    //return this.http.put<Tarea>('${this.api}/${tarea.id}', tarea);
    return this.http.put<Tarea>(this.api, tarea);
  }

  deleteTareaById(id:number):Observable<any>{
    return this.http.delete(this.api+'/'+id);
  }
}
