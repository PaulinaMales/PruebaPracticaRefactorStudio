import { NumberSymbol } from "@angular/common";

export class Tarea {
    //Definir los atributos que se reciben para que puedan mappearse
    constructor(
        public id: number , // Permite null
        public titulo : string,
        public descripcion :string,
        public completado: boolean
    ){}
}
