import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TareaListComponent } from './component/tarea-list/tarea-list.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { TareaAddComponent } from './component/tarea-add/tarea-add.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    TareaListComponent,
    TareaAddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [TareaListComponent, TareaAddComponent]
})
export class AppModule { }
