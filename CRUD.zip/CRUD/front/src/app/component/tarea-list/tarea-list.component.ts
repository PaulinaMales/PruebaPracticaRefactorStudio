import { Component } from '@angular/core';
import { Tarea } from '../../tarea';
import { TareaService } from '../../service/tarea.service';

@Component({
  selector: 'app-tarea-list',
  standalone: false,
  templateUrl: './tarea-list.component.html',
  styleUrl: './tarea-list.component.css'
})
export class TareaListComponent {
 //Variable
 tareas : Tarea[] =[];

 //CONTRUCTOR(Objeto)
 constructor(private tareaService: TareaService){}
 
 ngOnInit(): void {
   this.listTareas();
   //throw new Error('Method not implemented.');
 }
 //METODO
 listTareas(){
   //Suscrirbirnos al metodo 
   this.tareaService.getTareaList().subscribe(
     data=>{
       this.tareas= data;
       //Imprimir la variable customers
       console.log(this.tareas);
     }
   );

 }
// Método para actualizar una tarea
updateTarea(tarea: Tarea): void {
  this.tareaService.updateTareaById(tarea).subscribe(
    (updateTareaById) => {
      console.log('Tarea actualizada:', updateTareaById);
      this.listTareas(); // Recargar las tareas después de la actualización
    },
    (error) => {
      console.error('Error al actualizar tarea:', error);
    }
  );
}
 deleteTarea(id:number){
    this.tareaService.deleteTareaById(id).subscribe(
      ()=>this.listTareas()
    );
 }

}
