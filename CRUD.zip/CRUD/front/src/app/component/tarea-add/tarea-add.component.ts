import { Component, OnInit } from '@angular/core';
import { TareaService } from '../../service/tarea.service';
import { Tarea } from '../../tarea';

@Component({
  selector: 'app-tarea-add',
  standalone: false,
  templateUrl: './tarea-add.component.html',
  styleUrl: './tarea-add.component.css'
})
export class TareaAddComponent implements OnInit {
  id: number = 0;
  titulo: string = '';
  descripcion: string = '';
  completado: boolean = false;

  message: string = '';
  messageType: 'success' | 'error' = 'success';

  // Constructor
  constructor(private tareaService: TareaService) {}
  //Variable
  tareas : Tarea[] =[];
  ngOnInit(): void {}

  // Método 
  listTareas(){
    //Suscrirbirnos al metodo 
    this.tareaService.getTareaList().subscribe(
      data=>{
        this.tareas= data;
        //Imprimir la variable customers
        console.log(this.tareas);
      }
    );
 
  }
  addTarea() {
    if (this.titulo.trim() === '') {
      this.showMessage('Campo titulo requerido.', 'error');
      return;
    }

    let tarea = new Tarea(this.id, this.titulo, this.descripcion, this.completado);
    console.log(tarea);

    this.tareaService.createTarea(tarea).subscribe(
      res => {
        console.log('Tarea creada con éxito:', res);
        this.showMessage('¡Tarea creada exitosamente!', 'success');
        this.titulo = '';
        this.descripcion = '';
        this.completado = false;
        this.listTareas();
      },
      error => {
        console.error('Error al crear tarea:', error);
        this.showMessage('Hubo un error al crear la tarea. Intenta nuevamente.', 'error');
      }
    );
  }

  private showMessage(message: string, type: 'success' | 'error') {
    this.message = message;
    this.messageType = type;
    setTimeout(() => {
      this.message = '';
    }, 5000); 
  }
}
