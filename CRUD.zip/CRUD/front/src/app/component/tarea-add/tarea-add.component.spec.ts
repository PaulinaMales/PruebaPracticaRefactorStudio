import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TareaAddComponent } from './tarea-add.component';

describe('TareaAddComponent', () => {
  let component: TareaAddComponent;
  let fixture: ComponentFixture<TareaAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TareaAddComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TareaAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
